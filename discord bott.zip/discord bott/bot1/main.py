#!/usr/bin/env python3
"""
MS Account Password Changer - Discord Bot Edition
Owner-controlled authentication system
"""

import discord
from discord.ext import commands
import os
import json
import asyncio
import io
import sys
from datetime import datetime
from typing import List, Dict, Optional
import traceback

# Import your automation modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from automation.core import scrape_account_info
from automation.acsr import submit_acsr_form
from automation.acsr_continue import continue_acsr_flow
from automation.reset_password import perform_password_reset
from utils.password_generator import generate_shulker_password

# Bot configuration
TOKEN = 'MTQ2Nzc3MzE5NzQ3MzgwODQ4Nw.GY2Lwe.hgj0QUePDNuJguqqEXGd_ctwGSxeaz7-ZVq76w',
PREFIX = '&'
SUPER_USER_ID = '1421209611901341929'
MAX_ACCOUNTS_PER_USER = 10
AUTH_FILE = 'authorized_users.json'

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)

# Data storage
user_sessions = {}  # user_id -> ProcessingSession
authorized_users = set()  # Set of authorized user IDs

class ProcessingSession:
    """Tracks user processing sessions"""
    def __init__(self, user_id: int):
        self.user_id = user_id
        self.accounts = []  # List of {email, password, new_password, status}
        self.current_index = 0
        self.auto_generate = True
        self.captcha_data = None  # {image_bytes, driver, token, tempmail, account_info}
        self.status = "idle"  # idle, processing, waiting_captcha, completed
        self.captcha_solution = None
    
    def add_account(self, email: str, password: str):
        self.accounts.append({
            'email': email,
            'password': password,
            'new_password': None,
            'status': 'pending',
            'result': None,
            'captcha_attempts': 0
        })
    
    def set_new_password(self, index: int, password: str):
        if 0 <= index < len(self.accounts):
            self.accounts[index]['new_password'] = password
    
    def update_status(self, index: int, status: str, result=None):
        if 0 <= index < len(self.accounts):
            self.accounts[index]['status'] = status
            if result:
                self.accounts[index]['result'] = result
    
    def increment_captcha_attempts(self, index: int):
        if 0 <= index < len(self.accounts):
            self.accounts[index]['captcha_attempts'] += 1
            return self.accounts[index]['captcha_attempts']
        return 0

def save_authorized_users():
    """Save authorized users to file"""
    with open(AUTH_FILE, 'w') as f:
        json.dump(list(authorized_users), f)

def load_authorized_users():
    """Load authorized users from file"""
    global authorized_users
    try:
        if os.path.exists(AUTH_FILE):
            with open(AUTH_FILE, 'r') as f:
                authorized_users = set(json.load(f))
                print(f"Loaded {len(authorized_users)} authorized users")
    except:
        authorized_users = set()

def is_super_user(ctx):
    """Check if user is the super user (owner)"""
    return ctx.author.id == SUPER_USER_ID

def is_authorized():
    """Check if user is authorized or super user"""
    async def predicate(ctx):
        if ctx.author.id == SUPER_USER_ID:
            return True
        if ctx.author.id in authorized_users:
            return True
        
        # For unauthorized users, show available commands
        if ctx.command.name in ['help', 'auth', 'unauth'] and ctx.author.id == SUPER_USER_ID:
            return True
            
        await ctx.send(
            f"❌ You are not authorized to use this bot.\n"
            f"Ask the owner (<@{SUPER_USER_ID}>) to authorize you with `{PREFIX}auth @yourname`",
            ephemeral=True
        )
        return False
    return commands.check(predicate)

@bot.event
async def on_ready():
    """Bot startup handler"""
    load_authorized_users()
    
    print(f'{bot.user} has connected to Discord!')
    print(f'Bot ID: {bot.user.id}')
    print(f'Super User ID: {SUPER_USER_ID}')
    print(f'Authorized Users: {len(authorized_users)}')
    print(f'Connected to {len(bot.guilds)} guild(s)')
    
    # Set custom status
    await bot.change_presence(activity=discord.Activity(
        type=discord.ActivityType.watching,
        name="Microsoft Accounts | !help"
    ))

@bot.command(name='help')
async def help_command(ctx):
    """Show available commands"""
    is_super = ctx.author.id == SUPER_USER_ID
    is_auth = ctx.author.id in authorized_users
    
    embed = discord.Embed(
        title="🔐 MS Account Password Changer - Bot Help",
        description="Automated Microsoft account password changer",
        color=discord.Color.blue()
    )
    
    # Commands for everyone
    embed.add_field(
        name="ℹ️ General",
        value="`!help` - Show this help message",
        inline=False
    )
    
    if is_super:
        embed.add_field(
            name="👑 Owner Commands",
            value=(
                f"`{PREFIX}auth @user` - Authorize a user\n"
                f"`{PREFIX}unauth @user` - Remove authorization\n"
                f"`{PREFIX}authlist` - List authorized users\n"
                f"`{PREFIX}clearauth` - Remove all authorized users"
            ),
            inline=False
        )
    
    if is_super or is_auth:
        embed.add_field(
            name="📋 Account Management",
            value=(
                f"`{PREFIX}add email:password` - Add single account\n"
                f"`{PREFIX}addfile` - Upload accounts.txt file\n"
                f"`{PREFIX}list` - Show queued accounts\n"
                f"`{PREFIX}clear` - Clear all accounts\n"
                f"`{PREFIX}password auto/manual` - Set password mode"
            ),
            inline=False
        )
        
        embed.add_field(
            name="⚙️ Processing",
            value=(
                f"`{PREFIX}start` - Start processing accounts\n"
                f"`{PREFIX}status` - Check current status\n"
                f"`{PREFIX}results` - Show processing results\n"
                f"`{PREFIX}captcha TEXT` - Solve CAPTCHA\n"
                f"`{PREFIX}stop` - Stop current processing"
            ),
            inline=False
        )
        
        embed.add_field(
            name="🔧 Utilities",
            value=(
                f"`{PREFIX}genpass <count>` - Generate passwords\n"
                f"`{PREFIX}test email:password` - Test single account\n"
                f"`{PREFIX}stats` - Show bot statistics"
            ),
            inline=False
        )
    
    embed.set_footer(text=f"Prefix: {PREFIX} | Owner: <@{SUPER_USER_ID}>")
    
    # Send as ephemeral if not authorized
    await ctx.send(embed=embed, ephemeral=not (is_super or is_auth))

@bot.command(name='auth')
async def authorize_user(ctx, user: discord.User = None):
    """Authorize a user to use the bot (Owner only)"""
    if not is_super_user(ctx):
        await ctx.send("❌ Only the owner can authorize users.", ephemeral=True)
        return
    
    if not user:
        await ctx.send(f"❌ Usage: `{PREFIX}auth @username`", ephemeral=True)
        return
    
    if user.id == SUPER_USER_ID:
        await ctx.send("🤨 The owner is already authorized.", ephemeral=True)
        return
    
    if user.id in authorized_users:
        await ctx.send(f"✅ {user.mention} is already authorized.", ephemeral=True)
        return
    
    authorized_users.add(user.id)
    save_authorized_users()
    
    embed = discord.Embed(
        title="✅ User Authorized",
        description=f"{user.mention} can now use the bot",
        color=discord.Color.green()
    )
    embed.add_field(name="Authorized By", value=ctx.author.mention, inline=True)
    embed.add_field(name="Total Authorized", value=len(authorized_users), inline=True)
    
    await ctx.send(embed=embed)
    
    # Notify the user
    try:
        await user.send(f"🎉 You've been authorized to use the **MS Account Password Changer** bot!\n"
                       f"Use `{PREFIX}help` to see available commands.")
    except:
        pass  # Can't DM user

@bot.command(name='unauth')
async def unauthorize_user(ctx, user: discord.User = None):
    """Remove a user's authorization (Owner only)"""
    if not is_super_user(ctx):
        await ctx.send("❌ Only the owner can unauthorize users.", ephemeral=True)
        return
    
    if not user:
        await ctx.send(f"❌ Usage: `{PREFIX}unauth @username`", ephemeral=True)
        return
    
    if user.id == SUPER_USER_ID:
        await ctx.send("😠 You cannot unauthorize the owner!", ephemeral=True)
        return
    
    if user.id not in authorized_users:
        await ctx.send(f"❌ {user.mention} is not authorized.", ephemeral=True)
        return
    
    authorized_users.remove(user.id)
    save_authorized_users()
    
    # Clear their session if they have one
    if user.id in user_sessions:
        del user_sessions[user.id]
    
    embed = discord.Embed(
        title="❌ User Unauthorized",
        description=f"{user.mention} can no longer use the bot",
        color=discord.Color.red()
    )
    embed.add_field(name="Removed By", value=ctx.author.mention, inline=True)
    embed.add_field(name="Total Authorized", value=len(authorized_users), inline=True)
    
    await ctx.send(embed=embed)

@bot.command(name='authlist')
async def list_authorized(ctx):
    """List all authorized users (Owner only)"""
    if not is_super_user(ctx):
        await ctx.send("❌ Only the owner can view the authorized list.", ephemeral=True)
        return
    
    if not authorized_users:
        await ctx.send("📭 No users are authorized (except the owner).", ephemeral=True)
        return
    
    embed = discord.Embed(
        title="👥 Authorized Users",
        color=discord.Color.blue()
    )
    
    user_list = []
    for user_id in authorized_users:
        user = bot.get_user(user_id)
        if user:
            user_list.append(f"{user.mention} (`{user.id}`)")
        else:
            user_list.append(f"`{user_id}` (User not found)")
    
    embed.add_field(
        name=f"Users ({len(authorized_users)})",
        value="\n".join(user_list) or "None",
        inline=False
    )
    
    embed.set_footer(text=f"Owner: <@{SUPER_USER_ID}>")
    await ctx.send(embed=embed, ephemeral=True)

@bot.command(name='clearauth')
async def clear_authorized(ctx):
    """Remove all authorized users (Owner only)"""
    if not is_super_user(ctx):
        await ctx.send("❌ Only the owner can clear authorized users.", ephemeral=True)
        return
    
    count = len(authorized_users)
    
    # Clear all sessions for authorized users
    for user_id in list(authorized_users):
        if user_id in user_sessions:
            del user_sessions[user_id]
    
    authorized_users.clear()
    save_authorized_users()
    
    embed = discord.Embed(
        title="🧹 Cleared All Authorizations",
        description=f"Removed {count} user(s)",
        color=discord.Color.orange()
    )
    embed.add_field(name="Owner", value=ctx.author.mention, inline=True)
    
    await ctx.send(embed=embed)

@bot.command(name='add')
@is_authorized()
async def add_account(ctx, *, account_data: str):
    """Add a single account (format: email:password)"""
    if ':' not in account_data:
        await ctx.send("❌ Invalid format. Use: `email:password`")
        return
    
    email, password = account_data.split(':', 1)
    email = email.strip()
    password = password.strip()
    
    if ctx.author.id not in user_sessions:
        user_sessions[ctx.author.id] = ProcessingSession(ctx.author.id)
    
    session = user_sessions[ctx.author.id]
    
    if len(session.accounts) >= MAX_ACCOUNTS_PER_USER:
        await ctx.send(f"❌ Maximum {MAX_ACCOUNTS_PER_USER} accounts per user.")
        return
    
    session.add_account(email, password)
    
    embed = discord.Embed(
        title="✅ Account Added",
        description=f"Added account to processing queue",
        color=discord.Color.green()
    )
    embed.add_field(name="Email", value=f"`{email}`", inline=False)
    embed.add_field(name="Queue Position", value=f"#{len(session.accounts)}", inline=True)
    embed.add_field(name="Total Accounts", value=len(session.accounts), inline=True)
    
    await ctx.send(embed=embed)

@bot.command(name='addfile')
@is_authorized()
async def add_file(ctx):
    """Upload accounts.txt file"""
    if not ctx.message.attachments:
        await ctx.send("❌ Please attach an accounts.txt file")
        return
    
    attachment = ctx.message.attachments[0]
    if not attachment.filename.endswith('.txt'):
        await ctx.send("❌ Please upload a .txt file")
        return
    
    content = await attachment.read()
    content = content.decode('utf-8')
    
    if ctx.author.id not in user_sessions:
        user_sessions[ctx.author.id] = ProcessingSession(ctx.author.id)
    
    session = user_sessions[ctx.author.id]
    added = 0
    errors = 0
    
    for line_num, line in enumerate(content.splitlines(), 1):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        
        if ':' not in line:
            errors += 1
            continue
        
        if len(session.accounts) >= MAX_ACCOUNTS_PER_USER:
            break
        
        email, password = line.split(':', 1)
        session.add_account(email.strip(), password.strip())
        added += 1
    
    embed = discord.Embed(
        title="📁 File Upload Complete",
        color=discord.Color.blue()
    )
    embed.add_field(name="Accounts Added", value=added, inline=True)
    embed.add_field(name="Errors", value=errors, inline=True)
    embed.add_field(name="Total in Queue", value=len(session.accounts), inline=True)
    
    await ctx.send(embed=embed)

@bot.command(name='list')
@is_authorized()
async def list_accounts(ctx):
    """List all accounts in queue"""
    if ctx.author.id not in user_sessions or not user_sessions[ctx.author.id].accounts:
        await ctx.send("📭 No accounts in queue.")
        return
    
    session = user_sessions[ctx.author.id]
    
    embed = discord.Embed(
        title=f"📋 Accounts Queue ({len(session.accounts)})",
        color=discord.Color.blue()
    )
    
    for i, acc in enumerate(session.accounts, 1):
        status_emoji = {
            'pending': '⏳',
            'processing': '🔄',
            'success': '✅',
            'failed': '❌',
            'waiting_captcha': '🖼️'
        }.get(acc['status'], '❓')
        
        embed.add_field(
            name=f"{status_emoji} Account #{i}",
            value=f"**Email:** `{acc['email']}`\n**Status:** {acc['status'].title()}",
            inline=False
        )
    
    await ctx.send(embed=embed)

@bot.command(name='password')
@is_authorized()
async def set_password_mode(ctx, mode: str):
    """Set password generation mode (auto or manual)"""
    if ctx.author.id not in user_sessions:
        user_sessions[ctx.author.id] = ProcessingSession(ctx.author.id)
    
    session = user_sessions[ctx.author.id]
    
    if mode.lower() == 'auto':
        session.auto_generate = True
        await ctx.send("✅ Password mode set to **Auto-generate** (ShulkerGen######)")
    elif mode.lower() == 'manual':
        session.auto_generate = False
        await ctx.send("✅ Password mode set to **Manual** (you'll enter passwords)")
    else:
        await ctx.send("❌ Invalid mode. Use `auto` or `manual`")

@bot.command(name='start')
@is_authorized()
async def start_processing(ctx):
    """Start processing accounts"""
    if ctx.author.id not in user_sessions or not user_sessions[ctx.author.id].accounts:
        await ctx.send("❌ No accounts to process. Add accounts first.")
        return
    
    session = user_sessions[ctx.author.id]
    
    if session.status == 'processing':
        await ctx.send("⚠️ Already processing accounts.")
        return
    
    # Start processing in background
    await ctx.send(f"🚀 Starting processing for {len(session.accounts)} account(s)...")
    asyncio.create_task(process_accounts(ctx, session))

async def process_accounts(ctx, session: ProcessingSession):
    """Process accounts in background"""
    session.status = 'processing'
    session.current_index = 0
    
    for i, account in enumerate(session.accounts):
        session.current_index = i
        session.update_status(i, 'processing')
        
        embed = discord.Embed(
            title=f"🔄 Processing Account {i+1}/{len(session.accounts)}",
            color=discord.Color.blue()
        )
        embed.add_field(name="Email", value=f"`{account['email']}`", inline=False)
        
        msg = await ctx.send(embed=embed)
        
        try:
            # Step 1: Generate or get password
            if session.auto_generate:
                new_password = generate_shulker_password()
                session.set_new_password(i, new_password)
            else:
                # Ask for password via DM
                try:
                    dm = await ctx.author.create_dm()
                    ask_embed = discord.Embed(
                        title="🔐 Enter Password",
                        description=f"Please enter the new password for:\n`{account['email']}`",
                        color=discord.Color.blue()
                    )
                    ask_embed.set_footer(text="You have 2 minutes to respond")
                    await dm.send(embed=ask_embed)
                    
                    def check(m):
                        return m.author == ctx.author and isinstance(m.channel, discord.DMChannel)
                    
                    password_msg = await bot.wait_for('message', timeout=120.0, check=check)
                    new_password = password_msg.content.strip()
                    session.set_new_password(i, new_password)
                    
                    if not new_password:
                        raise ValueError("No password provided")
                        
                except asyncio.TimeoutError:
                    session.update_status(i, 'failed', 'Password input timeout')
                    embed.color = discord.Color.red()
                    embed.add_field(name="❌ Timeout", value="No password received in time", inline=False)
                    await msg.edit(embed=embed)
                    continue
                except Exception as e:
                    session.update_status(i, 'failed', str(e))
                    embed.color = discord.Color.red()
                    embed.add_field(name="❌ Error", value=str(e), inline=False)
                    await msg.edit(embed=embed)
                    continue
            
            # Step 2: Scrape account info
            embed.add_field(name="Step", value="Scraping account info...", inline=False)
            await msg.edit(embed=embed)
            
            account_info = scrape_account_info(account['email'], account['password'])
            
            if account_info.get("error"):
                session.update_status(i, 'failed', account_info['error'])
                embed.color = discord.Color.red()
                embed.add_field(name="❌ Error", value=account_info['error'], inline=False)
                await msg.edit(embed=embed)
                continue
            
            # Step 3: Submit ACSR form
            embed.add_field(name="Step", value="Submitting ACSR form...", inline=False)
            await msg.edit(embed=embed)
            
            captcha_img, driver, token, tempmail = submit_acsr_form(account_info)
            
            if not captcha_img:
                session.update_status(i, 'failed', "ACSR form submission failed")
                embed.color = discord.Color.red()
                embed.add_field(name="❌ Error", value="ACSR form submission failed", inline=False)
                await msg.edit(embed=embed)
                continue
            
            # Step 4: Save CAPTCHA and ask for solution
            session.captcha_data = {
                'image_bytes': captcha_img.read(),
                'driver': driver,
                'token': token,
                'tempmail': tempmail,
                'account_info': account_info,
                'account_index': i,
                'message_id': msg.id
            }
            session.update_status(i, 'waiting_captcha')
            
            # Send CAPTCHA image
            captcha_file = discord.File(
                io.BytesIO(session.captcha_data['image_bytes']),
                filename=f"captcha_{i}.png"
            )
            
            embed.add_field(name="Step", value="CAPTCHA Required", inline=False)
            embed.add_field(
                name="Instructions",
                value=f"Use `{PREFIX}captcha TEXT` to solve this CAPTCHA\nTimeout: 5 minutes",
                inline=False
            )
            embed.color = discord.Color.orange()
            await msg.edit(embed=embed)
            await ctx.send(file=captcha_file)
            
            # Wait for CAPTCHA solution
            captcha_solution = await wait_for_captcha(ctx, session, timeout=300)
            
            if not captcha_solution:
                session.update_status(i, 'failed', 'CAPTCHA timeout')
                embed.color = discord.Color.red()
                embed.add_field(name="❌ Timeout", value="No CAPTCHA received in time", inline=False)
                await msg.edit(embed=embed)
                continue
            
            # Step 5: Continue ACSR flow
            embed.color = discord.Color.blue()
            embed.remove_field(-1)  # Remove instructions
            embed.add_field(name="Step", value="Continuing ACSR flow...", inline=False)
            await msg.edit(embed=embed)
            
            reset_link = continue_acsr_flow(
                driver, account_info, token,
                captcha_solution, f"discord_{ctx.author.id}_{i}"
            )
            
            # Handle CAPTCHA retry
            retry_count = 0
            max_retries = 3
            while reset_link == "CAPTCHA_RETRY_NEEDED" and retry_count < max_retries:
                retry_count += 1
                attempts = session.increment_captcha_attempts(i)
                
                if attempts >= max_retries:
                    session.update_status(i, 'failed', f"Too many CAPTCHA failures ({attempts})")
                    embed.color = discord.Color.red()
                    embed.add_field(name="❌ Failed", value=f"Too many CAPTCHA failures ({attempts})", inline=False)
                    await msg.edit(embed=embed)
                    break
                
                embed.add_field(
                    name=f"⚠️ CAPTCHA Retry {retry_count}/{max_retries}",
                    value="Enter correct CAPTCHA:",
                    inline=False
                )
                embed.color = discord.Color.orange()
                await msg.edit(embed=embed)
                
                # Get new CAPTCHA
                captcha_solution = await wait_for_captcha(ctx, session, timeout=300)
                if not captcha_solution:
                    break
                
                reset_link = continue_acsr_flow(
                    driver, account_info, token,
                    captcha_solution, f"discord_{ctx.author.id}_{i}_retry{retry_count}"
                )
            
            if not reset_link or reset_link in ["CAPTCHA_RETRY_NEEDED", "OTP not received.", "CAPTCHA_DOWNLOAD_FAILED"]:
                session.update_status(i, 'failed', f"Reset link failed: {reset_link}")
                embed.color = discord.Color.red()
                embed.add_field(name="❌ Error", value=f"Reset link failed: {reset_link}", inline=False)
                await msg.edit(embed=embed)
                continue
            
            # Step 6: Reset password
            embed.add_field(name="Step", value="Resetting password...", inline=False)
            await msg.edit(embed=embed)
            
            updated_password = perform_password_reset(
                reset_link, account['email'], new_password
            )
            
            # Success!
            session.update_status(i, 'success', {
                'new_password': updated_password,
                'old_password': account['password'],
                'account_info': account_info
            })
            
            embed.color = discord.Color.green()
            embed.add_field(name="✅ Success", value="Password changed!", inline=False)
            embed.add_field(name="New Password", value=f"`{updated_password}`", inline=False)
            await msg.edit(embed=embed)
            
            # Wait between accounts
            if i < len(session.accounts) - 1:
                await asyncio.sleep(5)
                
        except Exception as e:
            session.update_status(i, 'failed', str(e))
            embed.color = discord.Color.red()
            embed.add_field(name="❌ Error", value=str(e), inline=False)
            await msg.edit(embed=embed)
            print(f"Error processing account: {e}")
            traceback.print_exc()
    
    session.status = 'completed'
    
    # Show summary
    successful = [a for a in session.accounts if a['status'] == 'success']
    failed = [a for a in session.accounts if a['status'] == 'failed']
    
    summary_embed = discord.Embed(
        title="📊 Processing Complete!",
        color=discord.Color.green() if successful else discord.Color.red()
    )
    summary_embed.add_field(name="✅ Successful", value=len(successful), inline=True)
    summary_embed.add_field(name="❌ Failed", value=len(failed), inline=True)
    summary_embed.add_field(name="⏳ Pending", value=len(session.accounts)-len(successful)-len(failed), inline=True)
    summary_embed.set_footer(text=f"User: {ctx.author}")
    
    await ctx.send(embed=summary_embed)

async def wait_for_captcha(ctx, session: ProcessingSession, timeout: int = 300):
    """Wait for user to provide CAPTCHA solution"""
    def check(m):
        return (
            m.author.id == ctx.author.id and
            m.channel.id == ctx.channel.id and
            m.content.startswith(f'{PREFIX}captcha ')
        )
    
    try:
        msg = await bot.wait_for('message', timeout=timeout, check=check)
        captcha_text = msg.content[len(f'{PREFIX}captcha '):].strip()
        session.captcha_solution = captcha_text
        return captcha_text
    except asyncio.TimeoutError:
        return None

@bot.command(name='captcha')
@is_authorized()
async def solve_captcha(ctx, *, captcha_text: str):
    """Solve a CAPTCHA for current processing"""
    if ctx.author.id not in user_sessions:
        await ctx.send("❌ No active session.")
        return
    
    session = user_sessions[ctx.author.id]
    
    if not session.captcha_data:
        await ctx.send("❌ No CAPTCHA pending.")
        return
    
    # Store CAPTCHA solution for processing task
    session.captcha_solution = captcha_text
    
    await ctx.send(f"✅ CAPTCHA submitted: `{captcha_text[:10]}...`")

@bot.command(name='status')
@is_authorized()
async def check_status(ctx):
    """Check processing status"""
    if ctx.author.id not in user_sessions:
        await ctx.send("📭 No active session.")
        return
    
    session = user_sessions[ctx.author.id]
    
    status_emoji = {
        'idle': '💤',
        'processing': '🔄',
        'waiting_captcha': '🖼️',
        'completed': '✅'
    }.get(session.status, '❓')
    
    embed = discord.Embed(
        title=f"{status_emoji} Processing Status",
        color=discord.Color.blue()
    )
    
    embed.add_field(name="Status", value=session.status.title(), inline=True)
    embed.add_field(name="Accounts", value=len(session.accounts), inline=True)
    embed.add_field(name="Current", value=f"#{session.current_index + 1}", inline=True)
    
    # Count statuses
    status_counts = {}
    for acc in session.accounts:
        status_counts[acc['status']] = status_counts.get(acc['status'], 0) + 1
    
    status_text = "\n".join([f"{s.title()}: {c}" for s, c in status_counts.items()])
    embed.add_field(name="Progress", value=status_text, inline=False)
    
    await ctx.send(embed=embed)

@bot.command(name='results')
@is_authorized()
async def show_results(ctx):
    """Show processing results"""
    if ctx.author.id not in user_sessions:
        await ctx.send("📭 No results available.")
        return
    
    session = user_sessions[ctx.author.id]
    
    successful = [a for a in session.accounts if a['status'] == 'success']
    failed = [a for a in session.accounts if a['status'] == 'failed']
    
    embed = discord.Embed(
        title="📊 Processing Results",
        color=discord.Color.green() if successful else discord.Color.red()
    )
    
    embed.add_field(name="✅ Successful", value=len(successful), inline=True)
    embed.add_field(name="❌ Failed", value=len(failed), inline=True)
    embed.add_field(name="⏳ Pending", value=len(session.accounts)-len(successful)-len(failed), inline=True)
    
    if successful:
        results_text = ""
        for acc in successful[:3]:  # Show first 3
            new_pass = acc.get('result', {}).get('new_password', 'Unknown')
            results_text += f"• `{acc['email'][:15]}...` → `{new_pass}`\n"
        
        if len(successful) > 3:
            results_text += f"\n...and {len(successful)-3} more"
        
        embed.add_field(name="Successful Accounts", value=results_text, inline=False)
    
    if failed:
        failed_text = ""
        for acc in failed[:3]:  # Show first 3 failures
            failed_text += f"• `{acc['email'][:15]}...`: {acc.get('result', 'Unknown error')}\n"
        
        if len(failed) > 3:
            failed_text += f"\n...and {len(failed)-3} more"
        
        embed.add_field(name="Failed Accounts", value=failed_text or "None", inline=False)
    
    await ctx.send(embed=embed)

@bot.command(name='genpass')
@is_authorized()
async def generate_password(ctx, count: int = 5):
    """Generate Shulker passwords"""
    if count > 20:
        count = 20
    
    passwords = [generate_shulker_password() for _ in range(count)]
    
    embed = discord.Embed(
        title="🔑 Generated Passwords",
        color=discord.Color.green()
    )
    
    password_list = "\n".join([f"`{p}`" for p in passwords])
    embed.add_field(name=f"{count} Passwords", value=password_list, inline=False)
    
    await ctx.send(embed=embed)

@bot.command(name='test')
@is_authorized()
async def test_account(ctx, *, account_data: str):
    """Test a single account without changing password"""
    if ':' not in account_data:
        await ctx.send("❌ Invalid format. Use: `email:password`")
        return
    
    email, password = account_data.split(':', 1)
    
    embed = discord.Embed(
        title="🧪 Testing Account",
        description=f"Testing `{email}`",
        color=discord.Color.blue()
    )
    
    msg = await ctx.send(embed=embed)
    
    try:
        # Try to scrape account info
        embed.add_field(name="Step", value="Scraping account info...", inline=False)
        await msg.edit(embed=embed)
        
        account_info = scrape_account_info(email, password)
        
        if account_info.get("error"):
            embed.color = discord.Color.red()
            embed.add_field(name="❌ Error", value=account_info['error'], inline=False)
            await msg.edit(embed=embed)
            return
        
        embed.color = discord.Color.green()
        embed.add_field(name="✅ Success", value="Account is valid!", inline=False)
        embed.add_field(name="Name", value=account_info.get('name', 'N/A'), inline=True)
        embed.add_field(name="Region", value=account_info.get('region', 'N/A'), inline=True)
        embed.add_field(name="Gamertag", value=account_info.get('gamertag', 'N/A'), inline=True)
        
        await msg.edit(embed=embed)
        
    except Exception as e:
        embed.color = discord.Color.red()
        embed.add_field(name="❌ Error", value=str(e), inline=False)
        await msg.edit(embed=embed)

@bot.command(name='stop')
@is_authorized()
async def stop_processing(ctx):
    """Stop current processing"""
    if ctx.author.id not in user_sessions:
        await ctx.send("📭 No active session to stop.")
        return
    
    session = user_sessions[ctx.author.id]
    
    if session.status != 'processing':
        await ctx.send("⚠️ No processing in progress.")
        return
    
    session.status = 'idle'
    await ctx.send("🛑 Processing stopped.")

@bot.command(name='clear')
@is_authorized()
async def clear_accounts(ctx):
    """Clear all accounts from queue"""
    if ctx.author.id not in user_sessions:
        await ctx.send("📭 No accounts to clear.")
        return
    
    count = len(user_sessions[ctx.author.id].accounts)
    user_sessions[ctx.author.id] = ProcessingSession(ctx.author.id)
    
    await ctx.send(f"🗑️ Cleared {count} account(s) from queue.")

@bot.command(name='stats')
@is_authorized()
async def show_stats(ctx):
    """Show bot statistics"""
    total_sessions = len(user_sessions)
    total_accounts = sum(len(s.accounts) for s in user_sessions.values())
    
    embed = discord.Embed(
        title="📊 Bot Statistics",
        color=discord.Color.purple()
    )
    
    embed.add_field(name="Active Sessions", value=total_sessions, inline=True)
    embed.add_field(name="Total Accounts Queued", value=total_accounts, inline=True)
    embed.add_field(name="Authorized Users", value=len(authorized_users), inline=True)
    
    # Count accounts by status
    status_counts = {'pending': 0, 'processing': 0, 'success': 0, 'failed': 0, 'waiting_captcha': 0}
    for session in user_sessions.values():
        for acc in session.accounts:
            if acc['status'] in status_counts:
                status_counts[acc['status']] += 1
    
    status_text = "\n".join([f"{s.title()}: {c}" for s, c in status_counts.items() if c > 0])
    embed.add_field(name="Account Statuses", value=status_text or "None", inline=False)
    
    embed.set_footer(text=f"Owner: <@{SUPER_USER_ID}> | Prefix: {PREFIX}")
    await ctx.send(embed=embed)

@bot.event
async def on_command_error(ctx, error):
    """Handle command errors"""
    if isinstance(error, commands.CommandNotFound):
        return
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"❌ Missing argument: `{error.param.name}`", ephemeral=True)
    elif isinstance(error, commands.CheckFailure):
        pass  # Already handled by is_authorized()
    else:
        await ctx.send(f"❌ Error: {str(error)[:100]}", ephemeral=True)
        print(f"Command error: {error}")
        traceback.print_exc()

def main():
    """Start the Discord bot"""
    if TOKEN == 'YOUR_BOT_TOKEN_HERE':
        print("❌ ERROR: Please set your Discord bot token!")
        print("1. Go to: https://discord.com/developers/applications")
        print("2. Create a new application")
        print("3. Go to 'Bot' section")
        print("4. Click 'Reset Token' and copy it")
        print("5. Replace 'YOUR_BOT_TOKEN_HERE' with your token")
        print("\nOr set environment variable:")
        print("  export DISCORD_BOT_TOKEN='your_token_here'")
        return
    
    if SUPER_USER_ID == 'YOUR_DISCORD_USER_ID_HERE':
        print("❌ ERROR: Please set your Discord User ID!")
        print("1. Enable Developer Mode in Discord Settings")
        print("2. Right-click your profile → Copy ID")
        print("3. Replace 'YOUR_DISCORD_USER_ID_HERE' with your ID")
        print("\nOr set environment variable:")
        print("  export SUPER_USER_ID='your_user_id_here'")
        return
    
    print("=" * 50)
    print("Starting MS Account Password Changer - Discord Bot")
    print("=" * 50)
    print(f"Prefix: {PREFIX}")
    print(f"Super User ID: {SUPER_USER_ID}")
    print(f"Max accounts per user: {MAX_ACCOUNTS_PER_USER}")
    print("=" * 50)
    
    try:
        bot.run(TOKEN)
    except discord.LoginFailure:
        print("❌ Invalid bot token! Please check your token.")
    except Exception as e:
        print(f"❌ Error starting bot: {e}")

if __name__ == "__main__":
    main()